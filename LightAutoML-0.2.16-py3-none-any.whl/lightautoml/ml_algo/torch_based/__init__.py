"""Models based on Torch library."""
